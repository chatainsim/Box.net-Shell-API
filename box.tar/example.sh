./box.sh -u -f box.tar -d 123456789

#You should have this output :  CHANGE THE FOLDER ID BY ONE OF YOURS
#
#Uploading file box.tar to folder ID 280147629.
#
#{"total_count":1,"entries":[{"type":"file","id":"2213921793","name":"box.tar","shared":"0","parent_folder":{"id":"280147629"}}]}
